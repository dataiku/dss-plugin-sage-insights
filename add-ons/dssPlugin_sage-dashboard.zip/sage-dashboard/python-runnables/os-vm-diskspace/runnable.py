from dataiku.runnables import Runnable
import dataiku
import os
import subprocess
import pandas as pd
from datetime import datetime

from sage.src import dss_folder, dss_funcs

class MyRunnable(Runnable):
    def __init__(self, project_key, config, plugin_config):
        self.project_key = project_key
        self.config = config
        self.plugin_config = plugin_config
        
    def get_progress_target(self):
        return None

    def run(self, progress_callback):
        # Dataiku root path
        client = dataiku.api_client()
        instance_name = dss_funcs.get_dss_name(client)
        root_path = client.get_instance_info().raw["dataDirPath"]
        os.chdir(root_path)
        
        # Find directories maxdepth
        cmd = "find . -maxdepth 3 -type d"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, check=True)
        directories = result.stdout.split("\n")
        directories.remove(".")
        
        # Get sizes of each directory
        data = []
        for d in directories:
            if not d:
                continue
            if "jupyter-run" in d:
                continue
            if ".git" in d:
                continue
            try:
                result = subprocess.run(f"du -sc {d}", shell=True, capture_output=True, text=True, check=True)
            except:
                continue
            size = result.stdout.split("\t")[0]
            data.append([d,size])

        # Build df and cleanse
        df = pd.DataFrame(data, columns=["directory", "size"])
        cols = ["dot", "level_1", "level_2", "level_3"]
        df[cols] = df["directory"].str.split("/",  expand=True)
        del df["dot"]
        del df["directory"]
        df['size'] = df['size'].astype(int)
        
        # Filter size on a base number (1gb / adjustable)
        gb = 1000000 * self.config.get("min_disk_space", 1)
        df = df[df["size"] >= gb]
        
        # Remove Directory and dupes
        df = df.drop_duplicates()
        df.reset_index(inplace=True)
        
        # Save
        dt = datetime.utcnow()
        dt_year  = str(dt.year)
        dt_month = str(f'{dt.month:02d}')
        dt_day   = str(f'{dt.day:02d}')
        dss_folder.write_folder_output(
            folder_name = "partitioned_data",
            path = f"/{instance_name}/disk_space/metadata/{dt_year}/{dt_month}/{dt_day}/data.csv",
            data = df
        )
        dss_folder.write_folder_output(
            folder_name = "base_data",
            path = f"/{instance_name}/disk_space/metadata.csv",
            data = df
        )
        
        # Done
        return "Data Gathered"