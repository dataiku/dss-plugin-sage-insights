from dataiku.runnables import Runnable
import dataiku
import os
import subprocess
import pandas as pd
from datetime import datetime

from sage.src import dss_folder, dss_funcs

def get_size(d):
    try:
        result = subprocess.run(f"du -sc {d}", shell=True, capture_output=True, text=True, check=True)
        size = result.stdout.split("\t")[0]
        size = int(size)
    except:
        size = 0
    return size


class MyRunnable(Runnable):
    def __init__(self, project_key, config, plugin_config):
        self.project_key = project_key
        self.config = config
        self.plugin_config = plugin_config
        
    def get_progress_target(self):
        return (4, "NONE")

    def run(self, progress_callback):
        # Datetime
        dt = datetime.utcnow()
        dt_year  = str(dt.year)
        dt_month = str(f'{dt.month:02d}')
        dt_day   = str(f'{dt.day:02d}')
        
        # Dataiku root path
        client = dataiku.api_client()
        instance_name = dss_funcs.get_dss_name(client)
        root_path = client.get_instance_info().raw["dataDirPath"]
        os.chdir(root_path)
        
        # Find directories maxdepth
        cmd = "find . -maxdepth 3 -type d"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, check=True)
        directories = result.stdout.split("\n")
        directories.remove(".")
        a = len(directories)
        
        # turn into a df
        df = pd.DataFrame(directories, columns=["directory"])

        # remove jupyter-run / .git -- permission issues with sudo stuff
        df = df[~df["directory"].str.contains("jupyter-run")]
        df = df[~df["directory"].str.contains(".git")]

        # Explode directory
        cols = ["dot", "level_1", "level_2", "level_3"]
        df[cols] = df["directory"].str.split("/",  expand=True)

        # remove columns
        del df["dot"]
        del df["directory"]
        progress_callback(1)
        
        # Get details on sizes - level_1
        df["level_1_size"] = 0
        for i,g in df.groupby(by=["level_1"]):
            d = "/".join(i)
            size = get_size(d)
            df.loc[df["level_1"] == i[0], "level_1_size"] = size
            
        # Filter size on a base number (1gb / adjustable)
        gb = 1000000 * self.config.get("min_disk_space", 1)
        df = df[df["level_1_size"] >= gb]
        progress_callback(2)

        # Get details on sizes - level_2
        df["level_2_size"] = 0
        for i,g in df.groupby(by=["level_1", "level_2"]):
            d = "/".join(i)
            size = get_size(d)
            df.loc[
                (df["level_1"] == i[0])
                & (df["level_2"] == i[1]), "level_2_size"] = size
        progress_callback(3)

        # Get details on sizes - level_3
        df["level_3_size"] = 0
        for i,g in df.groupby(by=["level_1", "level_2", "level_3"]):
            d = "/".join(i)
            size = get_size(d)
            df.loc[
                (df["level_1"] == i[0])
                & (df["level_2"] == i[1])
                & (df["level_3"] == i[2]), "level_3_size"] = size
        progress_callback(4)
        
        return df.to_html(index=False)