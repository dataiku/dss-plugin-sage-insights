from dataiku.runnables import Runnable
import dataiku
import pandas as pd
import os
from datetime import datetime

from sage.src import dss_funcs
from sage.src import dss_folder

class MyRunnable(Runnable):
    def __init__(self, project_key, config, plugin_config):
        self.project_key = project_key
        self.config = config
        self.plugin_config = plugin_config
        
    def get_progress_target(self):
        return None

    def run(self, progress_callback):
        # Dataiku root path
        client = dataiku.api_client()
        instance_name = dss_funcs.get_dss_name(client)
        root_path = client.get_instance_info().raw["dataDirPath"]
        os.chdir(root_path)
        
        # Walk tree
        data = []
        for root, dirs, files in os.walk("."):
            data.append({'Directory': root})
        df = pd.DataFrame(data)

        # Filter GIT
        df = df[~df["Directory"].str.contains(".git", case=False, na=False)]
        
        # Split up Directory
        cols = ["dot", "level_1", "level_2", "level_3", "trash"]
        df[cols] = df['Directory'].str.split("/", n=4, expand=True)
        del df["dot"]
        del df["trash"]
        df = df[~df["level_1"].isin(["jupyter-run"])]
        
        # Get sizes
        df["level_1_size"] = 0
        for i,g in df.groupby(by=["level_1"]):
            p = i
            size = dss_funcs.get_dir_size(p)
            df.loc[df["level_1"] == i, "level_1_size"] = size

        df["level_2_size"] = 0
        for i,g in df.groupby(by=["level_1", "level_2"]):
            p = "/".join(i)
            size = dss_funcs.get_dir_size(p)
            df.loc[
                (df["level_1"] == i[0])
                & (df["level_2"] == i[1]), "level_2_size"
            ] = size

        df["level_3_size"] = 0
        for i,g in df.groupby(by=["level_1", "level_2", "level_3"]):
            p = "/".join(i)
            size = dss_funcs.get_dir_size(p)
            df.loc[
                (df["level_1"] == i[0])
                & (df["level_2"] == i[1])
                & (df["level_3"] == i[2]), "level_3_size"
            ] = size
        
        # Filter level 1 lower than 5GB
        gb = 1000000000 * self.config.get("min_disk_space", 1)
        df = df[df["level_1_size"] >= gb]
        
        # Remove Directory and dupes
        del df["Directory"]
        df = df.drop_duplicates()
        
        # Save
        dt = datetime.utcnow()
        dt_year  = str(dt.year)
        dt_month = str(f'{dt.month:02d}')
        dt_day   = str(f'{dt.day:02d}')
        dss_folder.write_folder_output(
            folder_name = "partitioned_data",
            path = f"/{instance_name}/disk_space/metadata/{dt_year}/{dt_month}/{dt_day}/data.csv",
            data = df
        )
        dss_folder.write_folder_output(
            folder_name = "base_data",
            path = f"/{instance_name}/disk_space/metadata.csv",
            data = df
        )
        
        # Done
        return "Data Gathered"