from dataiku.runnables import Runnable
import dataiku
import os
import subprocess
import pandas as pd
from datetime import datetime

from sage.src import dss_folder, dss_funcs

class MyRunnable(Runnable):

    def __init__(self, project_key, config, plugin_config):
        self.project_key = project_key
        self.config = config
        self.plugin_config = plugin_config
        
    def get_progress_target(self):
        return None

    def run(self, progress_callback):
        # Datetime
        dt = datetime.utcnow()
        dt_year  = str(dt.year)
        dt_month = str(f'{dt.month:02d}')
        dt_day   = str(f'{dt.day:02d}')
        
        # Dataiku root path
        client = dataiku.api_client()
        instance_name = dss_funcs.get_dss_name(client)
        root_path = client.get_instance_info().raw["dataDirPath"]
        os.chdir(root_path)
        
        # Get a Filesystem disk space usage as well
        cmd = "df"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, check=True)
        result = result.stdout.split("\n")
        result.pop(0)
        data = []
        for line in result:
            line = " ".join(line.split())
            line = line.split(" ")
            data.append(line)
        df = pd.DataFrame(data, columns=["filesystem", "size", "used", "available", "used_pct", "mounted_on"]).dropna()
        df['used_pct'] = df['used_pct'].str.replace(r'[^a-zA-Z0-9\s]', '', regex=True)
        df = df[~df["filesystem"].isin(["devtmpfs", "tmpfs"])]
        df["instance_name"] = instance_name

        return df.to_html(index=False)