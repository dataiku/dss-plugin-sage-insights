from dataiku.runnables import Runnable
import dataiku
import pandas as pd

from sage.src import dss_funcs
from sage.src import dss_folder

class MyRunnable(Runnable):
    def __init__(self, project_key, config, plugin_config):
        self.project_key = project_key
        self.config = config
        self.plugin_config = plugin_config
        
    def get_progress_target(self):
        return None

    def run(self, progress_callback):
        # Dataiku root path
        client = dataiku.api_client()
        instance_name = dss_funcs.get_dss_name(client)
        root = client.get_instance_info().raw["dataDirPath"]

        # Save this df
        data = dss_funcs.get_directories_os(root)
        df = pd.DataFrame(data, columns=["directory", "size"])
        dss_folder.write_folder_output(
            folder_name = "base_data",
            path = f"/{instance_name}/os_vm/disk_space.csv",
            data = df
        )
        
        # top 10 heavy hitters
        top10 = df.sort_values(by=["size"], ascending=False).iloc[:10]
        heavy_hitters = pd.DataFrame()
        for dir in top10.directory.tolist():
            data = dss_funcs.get_directories_os(f"{root}/{dir}")
            tdf = pd.DataFrame(data, columns=["directory", "size"])
            tdf["root"] = dir
            tdf = tdf[["root", "directory", "size"]]
            if heavy_hitters.empty:
                heavy_hitters = tdf
            else:
                heavy_hitters = pd.concat([heavy_hitters, tdf], ignore_index=True)
        dss_folder.write_folder_output(
            folder_name = "base_data",
            path = f"/{instance_name}/os_vm/disk_space_heavy.csv",
            data = heavy_hitters
        )
        
        # Done
        return "Data Gathered"